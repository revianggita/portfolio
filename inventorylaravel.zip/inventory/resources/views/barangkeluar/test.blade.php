

    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Merk</th>
            <th>Spesifikasi</th>
            <th>Stok</th>
            <th>Lokasi</th>
            <th width="280px">Aksi</th>
        </tr>
        @foreach ($rsBarang as $barang)
        <tr>
  
            <td>{{ $barang->nama }}</td>
            <td>{{ $barang->merk }}</td>
            <td>{{ $barang->spesifikasi }}</td>
            <td>{{ $barang->stok }}</td>
            <td>{{ $barang->kategori->kategori }}</td>
        </tr>
        @endforeach
    </table>
 