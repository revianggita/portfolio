@extends('layout')
 
@section('content')
	<br />
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="float-left">
                <h3>Barang Keluar</h3>
            </div>
            <div class="float-right">
                <a class="btn btn-success" href="{{ route('barangkeluar.create') }}"> Tambah Barang Keluar</a>
            </div>
        </div>
    </div>
   <br />

    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif
   
 
    <table class="table table-bordered">
        <tr style="background-color: #CFD8DC;">
            <th>No</th>
            <th>Nama</th>
            <th>Merk</th>
            <th>Spesifikasi</th>
            <th>Jumlah</th>
            <th>Kategori</th>
            <th>Tanggal Keluar</th>
            <th width="180px">Aksi</th>
        </tr>
        @foreach ($rsBarangkeluar as $barangkeluar)
        <tr>
            <td>{{ ++$i }}</td>
            <td>{{ $barangkeluar->barang->nama }}</td>
            <td>{{ $barangkeluar->barang->merk }}</td>
            <td>{{ $barangkeluar->barang->spesifikasi }}</td>
            <td>{{ $barangkeluar->jumlah }}</td>
            <td>{{ $barangkeluar->barang->kategori->kategori }}</td>
            <td>{{ $barangkeluar->tgl_keluar }}</td>
         
          
            
            <td>
                <form action="{{ route('barangkeluar.destroy',$barangkeluar->id) }}" method="POST">
		    <a class="btn btn-info btn-sm" href="{{ route('barangkeluar.show',$barangkeluar->id) }}">Lihat</a>
   					
                    <a class="btn btn-primary btn-sm" href="{{ route('barangkeluar.edit',$barangkeluar->id) }}">Edit</a>
   		    
                    @csrf
                    @method('DELETE')
      
                    <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                </form>
            </td>
        </tr>
        @endforeach
    </table>
  
    {!! $rsBarangkeluar->links('vendor.pagination.bootstrap-4') !!}
      
@endsection