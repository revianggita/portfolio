@extends('layout')
   
@section('content')
	<br />
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Edit Barang Keluar</h2>
            </div>
	<br />
            <div class="pull-right">
                <a class="btn btn-primary" href="{{ route('barangkeluar.index') }}"> Back</a>
            </div>
        </div>
    </div>
   <br />
    @if ($errors->any())
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
  	
	<form action="{{ route('barangkeluar.update',$barangkeluar->id)}}" method="POST">
        @csrf
        @method('PUT')
   
        <div class="row">
        	<div class="col-xs-12 col-sm-12 col-md-12">
            	<div class="form-group">
            		<input type="hidden" name="id" value="{{$barangkeluar->id}}">
            		<input type="hidden" name="barang_id" value="{{$barangkeluar->barang_id}}">
            		<input type="hidden" name="jumlah_lama" value="{{$barangkeluar->jumlah}}"/>
                	<strong>Nama Barang | Merk :</strong>              
                	<select class="form-control" id="exampleFormControlSelect1" name="barang_id">
      					@foreach ($rsBarang as $brg)
      						@if($brg->id==$barangkeluar->barang_id)
      							<option value="{{$brg->id}}" selected="selected">{{ $brg->nama." | ".$brg->merk." | ".$brg->spesifikasi }}</option>
      						@else
      							<option value="{{$brg->id}}">{{ $brg->nama." | ".$brg->merk." } ".$brg->spesifikasi }}</option>
      						@endif
      					@endforeach
    				</select>
            	</div>
        	</div>
        	
       		<div class="col-xs-12 col-sm-12 col-md-12">
            	<div class="form-group">
                	<strong>Tanggal Keluar :</strong>
                	<input type="text" name="tgl_keluar" value="{{$barangkeluar->tgl_keluar}}" class="form-control datepicker">
            	</div>
         	</div>
         	
         	<div class="col-xs-12 col-sm-12 col-md-12">
            	<div class="form-group">
                	<strong>Jumlah :</strong>
                	<input type="text" name="jumlah" value="{{$barangkeluar->jumlah}}" class="form-control">
            	</div>
         	</div>  

            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
              <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>
   
    </form>
@endsection