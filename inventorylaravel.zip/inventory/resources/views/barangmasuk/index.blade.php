@extends('layout')
  
@section('content')
	<br />
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="float-left">
                <h3>Barang Masuk</h3>
            </div>
            <div class="float-right">
                <a class="btn btn-success btn-md" href="{{ route('barangmasuk.create') }}"> Tambah Barang Masuk</a>
            </div>
        </div>
    </div>
   <br />

    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif
   
 
    <table class="table table-bordered">
        <tr style="background-color: #CFD8DC;">
            <th>No</th>
            <th>Nama</th>
            <th>Merk</th>
            <th>Spesifikasi</th>
            <th>Jumlah</th>
            <th>Kategori</th>
            <th>Tanggal Masuk</th>
            <th width="180px">Aksi</th>
        </tr>
        @foreach ($rsBarangmasuk as $barangmasuk)
        <tr>
            <td>{{ ++$i }}</td>
            <td>{{ $barangmasuk->barang->nama }}</td>
            <td>{{ $barangmasuk->barang->merk }}</td>
            <td>{{ $barangmasuk->barang->spesifikasi }}</td>
            <td>{{ $barangmasuk->jumlah }}</td>
            <td>{{ $barangmasuk->barang->kategori->kategori }}</td>
            <td>{{ $barangmasuk->tgl_masuk }}</td>
         
          
            
            <td>
                <form action="{{ route('barangmasuk.destroy',$barangmasuk->id) }}" method="POST">
   					
    		    <a class="btn btn-info btn-sm" href="{{ route('barangmasuk.show',$barangmasuk->id) }}">Lihat</a>

                    <a class="btn btn-primary btn-sm" href="{{ route('barangmasuk.edit',$barangmasuk->id) }}">Edit</a>
   
                    @csrf
                    @method('DELETE')
      
                    <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                </form>
            </td>
        </tr>
        @endforeach
    </table>
  
     {!! $rsBarangmasuk->links('vendor.pagination.bootstrap-4') !!}       
@endsection