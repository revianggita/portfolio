@extends('layout')
   
@section('content')
<br />
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Detil Barang</h2>
            </div>
<br />
            <div class="pull-right">
                <a class="btn btn-primary" href="{{ route('barangmasuk.index') }}"> Back</a>
            </div>
        </div>
    </div>
   <br />
    @if ($errors->any())
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
  	
    <form action="{{ route('barangmasuk.update',$barangmasuk->id) }}" method="POST">
        @csrf
        @method('PUT')
   
         <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">

                <table class="table">
                    <tr>
                        <td>Nama</td>
                        <td>{{ $nama }}</td>
                    </tr>
                    <tr>
                        <td>Merk</td>
                        <td>{{ $merk }}</td>
                    </tr>
                    <tr>
                        <td>Spesifikasi</td>
                        <td>{{ $spesifikasi }}</td>
                    </tr>
                    <tr>
                        <td>Jumlah</td>
                        <td>{{ $barangmasuk->jumlah }}</td>
                    </tr>
		    <tr>
                        <td>Tanggal Masuk</td>
                        <td>{{ $barangmasuk->tgl_masuk }}</td>
                    </tr>
                </table>
            </div>
        </div>
	</form>
@endsection