<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Sistem Informasi Inventory </title>

  <!-- Bootstrap core CSS -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.8.0/css/bootstrap-datepicker.css">
  
  <link href="<?php echo url('/assets/vendor/bootstrap/css/bootstrap.min.css'); ?>" rel="stylesheet">
    
  <!-- Custom styles for this template -->
  <link href="<?php echo url('/assets/css/simple-sidebar.css'); ?>" rel="stylesheet">
  <link href="<?php echo url('/assets/css/bootstrap-datepicker.css'); ?>" rel="stylesheet">	


</head>

<body>

  <div class="d-flex" id="wrapper">

    <!-- Sidebar -->
    <div class="border-right text-white" style="background-color: #2196F3;" id="sidebar-wrapper">
      <div class="sidebar-heading">Inventory</div>
      <div class="list-group list-group-flush">
        <a href="{{ route('kategori.index') }}" class="list-group-item list-group-item-action text-white" style="background-color: #2196F3;">Kategori Barang</a>
        <a href="{{ route('barang.index') }}" class="list-group-item list-group-item-action text-white" style="background-color: #2196F3;">Data Barang</a>
        <a href="{{ route('barangmasuk.index') }}" class="list-group-item list-group-item-action text-white" style="background-color: #2196F3;">Barang Masuk</a>
        <a href="{{ route('barangkeluar.index') }}" class="list-group-item list-group-item-action text-white" style="background-color: #2196F3;">Barang Keluar</a>
      </div>
    </div>
    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    <div id="page-content-wrapper">

      <nav class="navbar navbar-expand-lg navbar-light" style="background-color: #E0E0E0;" border-bottom">
        <button class="btn btn-outline-primary text-black" id="menu-toggle">Toggle Menu</button>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
            <li class="nav-item active">
             <form method="POST" action="{{ route('logout') }}" class="glyphicon glyphicon-log-in">
                @csrf
                   <x-jet-dropdown-link href="{{ route('logout') }}"
                       onclick="event.preventDefault();
                       this.closest('form').submit();">
                       {{ __('Logout') }}
                   </x-jet-dropdown-link>
            </form>
            </li>
          </ul>
        </div>
      </nav>

      <div class="container-fluid">
        @yield('content')
      </div>
    </div>
    <!-- /#page-content-wrapper -->

  </div>
  <!-- /#wrapper -->

  <!-- Bootstrap core JavaScript
  	   <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.8.0/js/bootstrap-datepicker.js">
   -->
  <script src="<?php echo url('/assets/vendor/jquery/jquery.min.js'); ?>"></script> 
  <script src="<?php echo url('/assets/vendor/bootstrap/js/bootstrap.bundle.min.js'); ?>"></script>
  <script src="<?php echo url('/assets/js/bootstrap-datepicker.js'); ?>"></script>
  
 
   <!-- Menu Toggle Script -->
  <script>
    $("#menu-toggle").click(function(e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });

  </script>
  
  <!-- seting format tanggal -->
  <script type="text/javascript">
  	$('.datepicker').datepicker({		
  		 format: 'yyyy-mm-dd',
  		 startDate: '-3d'	
	});
  </script>
 
 <!-- hapus pesan flash 5 detik-->
  <script>
 	$("document").ready(function(){
    setTimeout(function(){
       $("div.alert").remove();
    }, 5000 ); // 5 secs
	});
  </script>

</body>

</html>
