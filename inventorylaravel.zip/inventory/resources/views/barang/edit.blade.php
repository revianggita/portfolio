@extends('layout')
   
@section('content')
<br />
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Edit barang</h2>
            </div>
<br />
            <div class="pull-right">
                <a class="btn btn-primary" href="{{ route('barang.index') }}"> Back</a>
            </div>
        </div>
    </div>
   <br />
    @if ($errors->any())
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
  	
    <form action="{{ route('barang.update',$barang->id) }}" method="POST">
        @csrf
        @method('PUT')
   
         <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Barang:</strong>
                    <input type="text" name="nama" value="{{ $barang->nama }}" class="form-control" placeholder="barang">
                </div>
            </div>
            
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Merk:</strong>
                    <input type="text" name="merk" value="{{ $barang->merk }}" class="form-control" placeholder="barang">
                </div>
            </div>
            
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Spesifikasi:</strong>
                    <input type="text" name="spesifikasi" value="{{ $barang->spesifikasi }}" class="form-control" placeholder="barang">
                </div>
            </div>
            
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Lokasi:</strong>
                    <input type="text" name="lokasi" value="{{ $barang->lokasi }}" class="form-control" placeholder="barang">
                </div>
            </div>
            
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Kategori:</strong>
                    <select class="form-control" id="exampleFormControlSelect1" name="kategori_id">
      				
      				@foreach($rsKategori as $kategori)
      					@if ($kategori->id==$barang->kategori_id)
      						<option value="{{$kategori->id}}" selected>{{$kategori->kategori}}</option>
      					@else
      						<option value="{{$kategori->id}}">{{$kategori->kategori}}</option>
      					@endif
      					
      				@endforeach
    			</select>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
              <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>
   
    </form>
@endsection