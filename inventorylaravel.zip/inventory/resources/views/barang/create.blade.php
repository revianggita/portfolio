@extends('layout')
  
@section('content')
<br />
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Tambah barang Baru</h2>
<br />
        </div>
        <div class="pull-right">
            <a class="btn btn-primary" href="{{ route('barang.index') }}"> Back</a>
        </div>
    </div>
</div>
  <br /> 
@if ($errors->any())
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

    
    
<form action="{{ route('barang.store') }}" method="POST">
    @csrf
  
     <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Nama:</strong>
                <input type="text" name="nama" class="form-control" placeholder="Nama Barang">
            </div>
            
            <div class="form-group">
                <strong>Merk:</strong>
                <input type="text" name="merk" class="form-control" placeholder="Merk">
            </div>
            <div class="form-group">
                <strong>Spesifikasi:</strong>
                <input type="text" name="spesifikasi" class="form-control" placeholder="Spesifikasi">
            </div>
            <div class="form-group">
                <strong>Lokasi:</strong>
                <input type="text" name="lokasi" class="form-control" placeholder="Lokasi Simpan">
            </div>
            
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Kategori:</strong>
                
                <select class="form-control" id="exampleFormControlSelect1" name="kategori_id">
      				@foreach ($rsKategori as $kategori)
      					<option value="{{$kategori->id}}">{{ $kategori->kategori }}</option>
      				@endforeach
    			</select>
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </div>
   
</form>
@endsection