@extends('layout')
 
@section('content')
<br />
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h3>Detil Kategori</h3>
            </div>
		</br>
         	<div class="pull-right">
			<a class="btn btn-outline-success" href="{{ route('kategori.index') }}">Back</a>
                </div>
		</br>
		<div class="pull-left">
                <table class="table">
                	<tr>
                		<td>Kategori</td>               		
                		<td>{{$recKategori}}</td>
                	</tr>
                	<tr>
                		<td>Keterangan</td>
                		<td>{{$recKeterangan}}</td>
                	</tr>
                </table>
            </div>
        </div>
    </div>
       
@endsection