@extends('layout')
   
@section('content')
	<br />
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Edit Kategori</h2>
	<br />
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="{{ route('kategori.index') }}"> Back</a>
            </div>
        </div>
    </div>
   <br />
    @if ($errors->any())
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
  	
  	<?php   
  		$aKeterangan=array(' '=>'',
  		                   'Modal'=>'Modal',
  		                   'Alat'=>'Alat',
  		                   'Bahan Habis Pakai'=>'Bahan Habis Pakai',
  		                   'Bahan Tidak Habis Pakai'=>'Bahan Tidak Habis Pakai');   
?> 
  	
    <form action="{{ route('kategori.update',$kategori->id) }}" method="POST">
        @csrf
        @method('PUT')
   
         <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Kategori:</strong>
                    <input type="text" name="kategori" value="{{ $kategori->kategori }}" class="form-control" placeholder="Kategori">
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Keterangan:</strong>
                    <select class="form-control" id="exampleFormControlSelect1" name="keterangan">
      				
      				@foreach($aKeterangan as $ket)
      					@if ($ket==$kategori->keterangan)
      						<option value="{{$ket}}" selected>{{$ket}}</option>
      					@else
      						<option value="{{$ket}}">{{$ket}}</option>
      					@endif
      					
      				@endforeach
    			</select>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
              <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>
   
    </form>
@endsection