@extends('layout')
  
@section('content')
	<br />
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Tambah Kategori Baru</h2>
        </div>
	<br />
        <div class="pull-right">
            <a class="btn btn-primary" href="{{ route('kategori.index') }}"> Back</a>
        </div>
    </div>
</div>
   <br />
@if ($errors->any())
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
   
<?php   
  		$aKeterangan=array(' '=>'',
  		                   'Modal'=>'Modal',
  		                   'Alat'=>'Alat',
  		                   'Bahan Habis Pakai'=>'Bahan Habis Pakai',
  		                   'Bahan Tidak Habis Pakai'=>'Bahan Tidak Habis Pakai');   
?>   
<form action="{{ route('kategori.store') }}" method="POST">
    @csrf
  
     <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Kategori:</strong>
                <input type="text" name="kategori" class="form-control" placeholder="Kategori">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Keterangan:</strong>
                
                <select class="form-control" id="exampleFormControlSelect1" name="keterangan">
      			   	@foreach($aKeterangan as $ket)
						<option value="{{$ket}}">{{$ket}}</option>
      				@endforeach
    			</select>
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </div>
   
</form>
@endsection