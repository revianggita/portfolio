  
<?php $__env->startSection('content'); ?>
<br />
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Tambah Barang Masuk Baru</h2>
        </div>
<br />
        <div class="pull-right">
            <a class="btn btn-primary" href="<?php echo e(route('barangmasuk.index')); ?>"> Back</a>
        </div>
    </div>
</div>
   <br />
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

    
    
<form action="<?php echo e(route('barangmasuk.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
  
     <div class="row">
     	<div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Nama Barang | Merk :</strong>
                
                <select class="form-control" id="exampleFormControlSelect1" name="barang_id">
      				<?php $__currentLoopData = $rsBarang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      					<option value="<?php echo e($barang->id); ?>"><?php echo e($barang->nama." | ".$barang->merk); ?></option>
      				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    			</select>
            </div>
        </div>
     
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Tanggal Masuk :</strong>
                <input type="text" name="tgl_masuk" class="form-control datepicker">
            </div>
         </div>  
            
            
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Jumlah :</strong>
                <input type="text" name="jumlah" class="form-control">
            </div>
         </div> 
             
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    
    </div>

</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/inventory/resources/views/barangmasuk/create.blade.php ENDPATH**/ ?>