   
<?php $__env->startSection('content'); ?>
<br />
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Detil Barang</h2>
            </div>
<br />
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(route('barang.index')); ?>"> Back</a>
            </div>
        </div>
    </div>
   <br />
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
  	
    <form action="<?php echo e(route('barang.update',$barang->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
   
         <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                
                <table class="table">
                	<tr>
                		<td>Barang</td>
                		<td><?php echo e($barang->nama); ?></td>
                	</tr>
                	<tr>
                		<td>Merk</td>
                		<td><?php echo e($barang->merk); ?></td>
                	</tr>
                	<tr>
                		<td>Spesifikasi</td>
                		<td><?php echo e($barang->spesifikasi); ?></td>
                	</tr>
                	<tr>
                		<td>Stok</td>
                		<td>
                			<?php if($barang->stok==''): ?>
                				<?php echo e(0); ?>

                			<?php else: ?>	
                				<?php echo e($barang->stok); ?>

                			<?php endif; ?>
                		</td>
                	</tr>
                	<tr>
                		<td>Lokasi</td>
                		<td><?php echo e($barang->lokasi); ?></td>
                	</tr>
                	<tr>
                		<td>Kategori</td>
                		<td><?php echo e($kategori); ?></td>
                	</tr>
                	<tr>
                		<td>Keterangan</td>
                		<td><?php echo e($keterangan); ?></td>
                	</tr>
                </table>
            </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/inventory/resources/views/barang/show.blade.php ENDPATH**/ ?>