  
<?php $__env->startSection('content'); ?>
	<br />
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="float-left">
                <h3>Barang Masuk</h3>
            </div>
            <div class="float-right">
                <a class="btn btn-success btn-md" href="<?php echo e(route('barangmasuk.create')); ?>"> Tambah Barang Masuk</a>
            </div>
        </div>
    </div>
   <br />

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
   
 
    <table class="table table-bordered">
        <tr style="background-color: #CFD8DC;">
            <th>No</th>
            <th>Nama</th>
            <th>Merk</th>
            <th>Spesifikasi</th>
            <th>Jumlah</th>
            <th>Kategori</th>
            <th>Tanggal Masuk</th>
            <th width="180px">Aksi</th>
        </tr>
        <?php $__currentLoopData = $rsBarangmasuk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barangmasuk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(++$i); ?></td>
            <td><?php echo e($barangmasuk->barang->nama); ?></td>
            <td><?php echo e($barangmasuk->barang->merk); ?></td>
            <td><?php echo e($barangmasuk->barang->spesifikasi); ?></td>
            <td><?php echo e($barangmasuk->jumlah); ?></td>
            <td><?php echo e($barangmasuk->barang->kategori->kategori); ?></td>
            <td><?php echo e($barangmasuk->tgl_masuk); ?></td>
         
          
            
            <td>
                <form action="<?php echo e(route('barangmasuk.destroy',$barangmasuk->id)); ?>" method="POST">
   					
    		    <a class="btn btn-info btn-sm" href="<?php echo e(route('barangmasuk.show',$barangmasuk->id)); ?>">Lihat</a>

                    <a class="btn btn-primary btn-sm" href="<?php echo e(route('barangmasuk.edit',$barangmasuk->id)); ?>">Edit</a>
   
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
      
                    <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
  
     <?php echo $rsBarangmasuk->links('vendor.pagination.bootstrap-4'); ?>       
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/inventory/resources/views/barangmasuk/index.blade.php ENDPATH**/ ?>