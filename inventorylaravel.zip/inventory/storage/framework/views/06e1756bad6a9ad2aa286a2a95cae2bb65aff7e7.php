  
<?php $__env->startSection('content'); ?>
<br />
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Tambah barang Baru</h2>
<br />
        </div>
        <div class="pull-right">
            <a class="btn btn-primary" href="<?php echo e(route('barang.index')); ?>"> Back</a>
        </div>
    </div>
</div>
  <br /> 
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

    
    
<form action="<?php echo e(route('barang.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
  
     <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Nama:</strong>
                <input type="text" name="nama" class="form-control" placeholder="Nama Barang">
            </div>
            
            <div class="form-group">
                <strong>Merk:</strong>
                <input type="text" name="merk" class="form-control" placeholder="Merk">
            </div>
            <div class="form-group">
                <strong>Spesifikasi:</strong>
                <input type="text" name="spesifikasi" class="form-control" placeholder="Spesifikasi">
            </div>
            <div class="form-group">
                <strong>Lokasi:</strong>
                <input type="text" name="lokasi" class="form-control" placeholder="Lokasi Simpan">
            </div>
            
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Kategori:</strong>
                
                <select class="form-control" id="exampleFormControlSelect1" name="kategori_id">
      				<?php $__currentLoopData = $rsKategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      					<option value="<?php echo e($kategori->id); ?>"><?php echo e($kategori->kategori); ?></option>
      				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    			</select>
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </div>
   
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/inventory/resources/views/barang/create.blade.php ENDPATH**/ ?>