 
<?php $__env->startSection('content'); ?>
	<br />
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="float-left">
                <h3>Barang Keluar</h3>
            </div>
            <div class="float-right">
                <a class="btn btn-success" href="<?php echo e(route('barangkeluar.create')); ?>"> Tambah Barang Keluar</a>
            </div>
        </div>
    </div>
   <br />

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
   
 
    <table class="table table-bordered">
        <tr style="background-color: #CFD8DC;">
            <th>No</th>
            <th>Nama</th>
            <th>Merk</th>
            <th>Spesifikasi</th>
            <th>Jumlah</th>
            <th>Kategori</th>
            <th>Tanggal Keluar</th>
            <th width="180px">Aksi</th>
        </tr>
        <?php $__currentLoopData = $rsBarangkeluar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barangkeluar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(++$i); ?></td>
            <td><?php echo e($barangkeluar->barang->nama); ?></td>
            <td><?php echo e($barangkeluar->barang->merk); ?></td>
            <td><?php echo e($barangkeluar->barang->spesifikasi); ?></td>
            <td><?php echo e($barangkeluar->jumlah); ?></td>
            <td><?php echo e($barangkeluar->barang->kategori->kategori); ?></td>
            <td><?php echo e($barangkeluar->tgl_keluar); ?></td>
         
          
            
            <td>
                <form action="<?php echo e(route('barangkeluar.destroy',$barangkeluar->id)); ?>" method="POST">
		    <a class="btn btn-info btn-sm" href="<?php echo e(route('barangkeluar.show',$barangkeluar->id)); ?>">Lihat</a>
   					
                    <a class="btn btn-primary btn-sm" href="<?php echo e(route('barangkeluar.edit',$barangkeluar->id)); ?>">Edit</a>
   		    
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
      
                    <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
  
    <?php echo $rsBarangkeluar->links('vendor.pagination.bootstrap-4'); ?>

      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/inventory/resources/views/barangkeluar/index.blade.php ENDPATH**/ ?>