   
<?php $__env->startSection('content'); ?>
	<br />
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Edit Barang Masuk</h2>
            </div>
		<br />
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(route('barangmasuk.index')); ?>"> Back</a>
            </div>
        </div>
    </div>
   <br />
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
  	
	<form action="<?php echo e(route('barangmasuk.update',$barangmasuk->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
   
        <div class="row">
        	<div class="col-xs-12 col-sm-12 col-md-12">
            	<div class="form-group">
            		<input type="hidden" name="id" value="<?php echo e($barangmasuk->id); ?>">
            		<input type="hidden" name="barang_id" value="<?php echo e($barangmasuk->barang_id); ?>">
            		<input type="hidden" name="jumlah_lama" value="<?php echo e($barangmasuk->jumlah); ?>"/>
                	<strong>Nama Barang | Merk :</strong>              
                	<select class="form-control" id="exampleFormControlSelect1" name="barang_id">
      					<?php $__currentLoopData = $rsBarang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      						<?php if($brg->id==$barangmasuk->barang_id): ?>
      							<option value="<?php echo e($brg->id); ?>" selected="selected"><?php echo e($brg->nama." | ".$brg->merk." | ".$brg->spesifikasi); ?></option>
      						<?php else: ?>
      							<option value="<?php echo e($brg->id); ?>"><?php echo e($brg->nama." | ".$brg->merk." } ".$brg->spesifikasi); ?></option>
      						<?php endif; ?>
      					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    				</select>
            	</div>
        	</div>
        	
       		<div class="col-xs-12 col-sm-12 col-md-12">
            	<div class="form-group">
                	<strong>Tanggal Masuk :</strong>
                	<input type="text" name="tgl_masuk" value="<?php echo e($barangmasuk->tgl_masuk); ?>" class="form-control datepicker">
            	</div>
         	</div>
         	
         	<div class="col-xs-12 col-sm-12 col-md-12">
            	<div class="form-group">
                	<strong>Jumlah :</strong>
                	<input type="text" name="jumlah" value="<?php echo e($barangmasuk->jumlah); ?>" class="form-control">
            	</div>
         	</div>  

            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
              <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>
   
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/inventory/resources/views/barangmasuk/edit.blade.php ENDPATH**/ ?>