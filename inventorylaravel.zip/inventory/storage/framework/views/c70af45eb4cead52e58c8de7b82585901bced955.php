 
<?php $__env->startSection('content'); ?>
	<br />
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="float-left">
                <h3>Data Barang</h3>
            </div>
            <div class="float-right">
                <a class="btn btn-success btn-md" href="<?php echo e(route('barang.create')); ?>"> Tambah data barang</a>
            </div>
        </div>
    </div>

    <div>
    	<div  style="background-color: #fff; padding: 20px; border-radius: 0.5rem; box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);">
            <div class="btn-toolbar justify-content-between" role="toolbar" aria-label="Toolbar with button groups" style="padding-bottom: 30px;" "pull-left">
	<div>
            <form  class="form-inline mt-2 mb-2 pull-right" action="<?php echo e(route('barang.index')); ?>" method="GET" role="search">
            <input name="term" id="term" class="form-control form-control-sm mr-sm-2" type="search" placeholder="Cari nama barang" aria-label="Search">
                <button class="btn btn-basics-search my-2 my-sm-0" type="submit">
		    	  <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-search" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  				    <path fill-rule="evenodd" d="M10.442 10.442a1 1 0 0 1 1.415 0l3.85 3.85a1 1 0 0 1-1.414 1.415l-3.85-3.85a1 1 0 0 1 0-1.415z"/>
  				    <path fill-rule="evenodd" d="M6.5 12a5.5 5.5 0 1 0 0-11 5.5 5.5 0 0 0 0 11zM13 6.5a6.5 6.5 0 1 1-13 0 6.5 6.5 0 0 1 13 0z"/>
			      </svg> | Search
		        </button>
                <a style="margin-left:10px;" class="btn btn-basics-refresh my-2 my-sm-0" href="<?php echo e(route('barang.index')); ?>" class=" mt-1">
	              <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-arrow-clockwise" fill="currentColor" xmlns="http://www.w3.org/2000/svg%22%3E">
                    <path fill-rule="evenodd" d="M8 3a5 5 0 1 0 4.546 2.914.5.5 0 0 1 .908-.417A6 6 0 1 1 8 2v1z"/>
                    <path d="M8 4.466V.534a.25.25 0 0 1 .41-.192l2.36 1.966c.12.1.12.284 0 .384L8.41 4.658A.25.25 0 0 1 8 4.466z"/>
                  </svg> | Refresh
	            </a>
            </form>
	      </div>
	</div>
        </div>
   
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
    
    <?php if($message = Session::get('failed')): ?>
    	<div class="alert alert-warning">
            <p><?php echo e($message); ?></p>
        </div>
   <?php endif; ?>
   
 
    <table class="table table-bordered">
        <tr style="background-color: #CFD8DC;">
            <th>No</th>
            <th>Nama</th>
            <th>Merk</th>
            <th>Spesifikasi</th>
            <th>Stok</th>
            <th>Lokasi</th>
            <th>Kategori</th>
            <th width="180px">Aksi</th>
        </tr>
        <?php $__currentLoopData = $rsBarang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(++$i); ?></td>
            <td><?php echo e($barang->nama); ?></td>
            <td><?php echo e($barang->merk); ?></td>
            <td><?php echo e($barang->spesifikasi); ?></td>
            <td>
            	<?php if($barang->stok==''): ?>
            		<?php echo e(0); ?>

            	<?php else: ?>
            		<?php echo e($barang->stok); ?>

            	<?php endif; ?>
            </td>
            <td><?php echo e($barang->lokasi); ?></td>
            <td><?php echo e($barang->kategori->kategori); ?></td>
            <td>
                <form action="<?php echo e(route('barang.destroy',$barang->id)); ?>" method="POST">
   
                    <a class="btn btn-info btn-sm" href="<?php echo e(route('barang.show',$barang->id)); ?>">Lihat</a>
    
                    <a class="btn btn-primary btn-sm" href="<?php echo e(route('barang.edit',$barang->id)); ?>">Edit</a>
   
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
      
                    <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
  
    <?php echo $rsBarang->links('vendor.pagination.bootstrap-4'); ?>

      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/inventory/resources/views/barang/index.blade.php ENDPATH**/ ?>