 
<?php $__env->startSection('content'); ?>
<br />
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h3>Detil Kategori</h3>
            </div>
		</br>
         	<div class="pull-right">
			<a class="btn btn-outline-success" href="<?php echo e(route('kategori.index')); ?>">Back</a>
                </div>
		</br>
		<div class="pull-left">
                <table class="table">
                	<tr>
                		<td>Kategori</td>               		
                		<td><?php echo e($recKategori); ?></td>
                	</tr>
                	<tr>
                		<td>Keterangan</td>
                		<td><?php echo e($recKeterangan); ?></td>
                	</tr>
                </table>
            </div>
        </div>
    </div>
       
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/inventory/resources/views/kategori/show.blade.php ENDPATH**/ ?>