<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBarangkeluarTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('barangkeluar', function (Blueprint $table) {
            $table->id();
	    $table->date('tgl_keluar');
	    $table->bigInteger('jumlah');
	    $table->unsignedBigInteger('barang_id');
	    $table->index('barang_id');
	    $table->foreign('barang_id')
		  ->references('id')
		  ->on('barang')
		  ->onDelete('restrict');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('barangkeluar');
    }
}
