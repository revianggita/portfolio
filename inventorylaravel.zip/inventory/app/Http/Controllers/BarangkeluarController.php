<?php

namespace App\Http\Controllers;

use App\Models\Barangkeluar;
use App\Models\Barang;
use App\Models\Kategori;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BarangkeluarController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $rsBarangkeluar = Barangkeluar::select('*')->with('barang.kategori')->Paginate(5);
    	 return view('barangkeluar.index',compact('rsBarangkeluar'))
    	             ->with('i', (request()->input('page', 1) - 1) * 5);;
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $rsBarang	= Barang::all();
        $rsKategori = Kategori::All();
        return view('barangkeluar.create',compact(['rsKategori','rsBarang']));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'tgl_keluar' => 'required',
            'jumlah' => 'required',
            'barang_id'=>'required'
        ]);       
       
       DB::beginTransaction();
        try {
            $barang = Barang::find($request->barang_id);
       
      // dd($barang); die('asdsa');
       
       if ($barang->stok==NULL){
	   		$barang->stok = $request->jumlah;
	   }       
       else {
	   	$barang->stok = $barang->stok-$request->jumlah;
	   }
    		
       $barang->save();
       
       
       Barangkeluar::create($request->all());
            DB::commit();
        } catch (\Exception $ex) {
            DB::rollback();
            return response()->json(['error' => $ex->getMessage()], 500);
        }
       
     
       return redirect()->route('barangkeluar.index')
                        ->with('success','barang created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Barangkeluar  $barangkeluar
     * @return \Illuminate\Http\Response
     */
    public function show(Barangkeluar $barangkeluar)
    {
        $barangkeluar    = Barangkeluar::find($barangkeluar->id);
        $recbarang      = $barangkeluar->barang;
        $nama           = $recbarang->nama;
        $merk           = $recbarang->merk;
        $spesifikasi    = $recbarang->spesifikasi;


        return view('barangkeluar.show',compact(['barangkeluar','nama','merk','spesifikasi']));    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Barangkeluar  $barangkeluar
     * @return \Illuminate\Http\Response
     */
    public function edit(Barangkeluar $barangkeluar)
    {
        $rsBarang	= Barang::all();
        return view('barangkeluar.edit',compact(['barangkeluar','rsBarang']));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Barangkeluar  $barangkeluar
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Barangkeluar $barangkeluar)
    {
        $jumlah_lama = $request->jumlah_lama;
    	
    	$barang = Barang::find($request->barang_id);
    	$stok_lama = $barang->stok;
    	$stok_reset = $stok_lama + $jumlah_lama;
    	$stok_update = $stok_reset-$request->jumlah;
    	
        $request->validate([
            'tgl_keluar' => 'required',
            'jumlah' => 'required'
        ]);
        
        DB::beginTransaction();
        try {
            //update stok barang
            $barang = Barang::find($request->barang_id);
            $barang->stok = $stok_update;
            $barang->save();
            
 	//update jumlah barangmasuk
            Barangkeluar::find($request->id)->update(['jumlah'=>$request->jumlah, 'tgl_keluar'=>$request->tgl_keluar]);
            DB::commit();
           
           //kembali ke halaman Barangmasuk
           return redirect()->route('barangkeluar.index')
                        ->with('success','barang updated successfully');
            
        } catch (\Exception $ex) {
            DB::rollback();
            //return response()->json(['error' => $ex->getMessage()], 500);
            return redirect()->route('barangkeluar.index')
                        ->with('failed','Barang keluar updated unsuccessfull');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Barangkeluar  $barangkeluar
     * @return \Illuminate\Http\Response
     */
    public function destroy(Barangkeluar $barangkeluar)
    {
        $barang = Barang::find($barangkeluar->barang_id);
        $stok = $barang->stok;
        $stok_baru = $stok + $barangkeluar->jumlah;
    	
        DB::beginTransaction();
        try {
            Barang::where('id',$barangkeluar->barang_id)->update(['stok'=>$stok_baru]);
 
            $barangkeluar->delete();
            DB::commit();
	    return redirect()->route('barangkeluar.index')
                        ->with('success','Barang Keluar deleted successfully');
        } catch (\Exception $ex) {
            DB::rollback();
            return response()->json(['error' => $ex->getMessage()], 500);
        }
    }
}
