<?php

namespace App\Http\Controllers;

use App\Models\Barangmasuk;
use App\Models\Barang;
use App\Models\Kategori;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BarangmasukController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $rsBarangmasuk = Barangmasuk::select('*')->with('barang.kategori')->Paginate(5);
    	 return view('barangmasuk.index',compact('rsBarangmasuk'))
    	             ->with('i', (request()->input('page', 1) - 1) * 5);;

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $rsBarang	= Barang::all();
        $rsKategori = Kategori::All();
        
        return view('barangmasuk.create',compact(['rsKategori','rsBarang']));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'tgl_masuk' => 'required',
            'jumlah' => 'required',
            'barang_id'=>'required'
        ]);
        
    
       
       DB::beginTransaction();
        try {
            $recBarang = Barang::find($request->barang_id);   

       		if ($recBarang->stok==NULL){
	   			$recBarang->stok = $request->jumlah;
	   		}       
       		else {
	   			$recBarang->stok = $recBarang->stok+$request->jumlah;
	   		}
    		
       		$recBarang->save();
       
       Barangmasuk::create($request->all());
            DB::commit();
            
            return redirect()->route('barangmasuk.index')
                        ->with('success','barang created successfully.');
            
        } catch (\Exception $ex) {
            DB::rollback();
            return redirect()->route('barangmasuk.index')
                        ->with('failed','Barang created unsuccessfully.');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Barangmasuk  $barangmasuk
     * @return \Illuminate\Http\Response
     */
    public function show(Barangmasuk $barangmasuk)
    {
        $barangmasuk    = Barangmasuk::find($barangmasuk->id);
        $recbarang      = $barangmasuk->barang;
        $nama           = $recbarang->nama;
        $merk           = $recbarang->merk;
        $spesifikasi    = $recbarang->spesifikasi;


        return view('barangmasuk.show',compact(['barangmasuk','nama','merk','spesifikasi']));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Barangmasuk  $barangmasuk
     * @return \Illuminate\Http\Response
     */
    public function edit(Barangmasuk $barangmasuk)
    {
        $rsBarang	= Barang::all();
        return view('barangmasuk.edit',compact(['barangmasuk','rsBarang']));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Barangmasuk  $barangmasuk
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Barangmasuk $barangmasuk)
    {
        $jumlah_lama = $request->jumlah_lama;
    	
    	$barang = Barang::find($request->barang_id);
    	$stok_lama = $barang->stok;
    	$stok_reset = $stok_lama - $jumlah_lama;
    	$stok_update = $stok_reset+$request->jumlah;
    	
    	
        $request->validate([
            'tgl_masuk' => 'required',
            'jumlah' => 'required'
        ]);
        
        
        DB::beginTransaction();
        try {
            //update stok barang
            $barang = Barang::find($request->barang_id);
            $barang->stok = $stok_update;
            $barang->save();
            
 	//update jumlah barangmasuk
            Barangmasuk::find($request->id)->update(['jumlah'=>$request->jumlah, 'tgl_masuk'=>$request->tgl_masuk]);
            DB::commit();
           
           //kembali ke halaman Barangmasuk
           return redirect()->route('barangmasuk.index')
                        ->with('success','barang updated successfully');
            
        } catch (\Exception $ex) {
            DB::rollback();
            //return response()->json(['error' => $ex->getMessage()], 500);
            return redirect()->route('barangmasuk.index')
                        ->with('failed','Barang masuk updated unsuccessfull');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Barangmasuk  $barangmasuk
     * @return \Illuminate\Http\Response
     */
    public function destroy(Barangmasuk $barangmasuk)
    {
        $barang = Barang::find($barangmasuk->barang_id);
        $stok = $barang->stok;
        $stok_baru = $stok - $barangmasuk->jumlah;
    	
        DB::beginTransaction();
        try {
            Barang::where('id',$barangmasuk->barang_id)->update(['stok'=>$stok_baru]);
 
            $barangmasuk->delete();
            DB::commit();
	    return redirect()->route('barangmasuk.index')
                        ->with('success','Barang Masuk deleted successfully');

        } catch (\Exception $ex) {
            DB::rollback();
            return response()->json(['error' => $ex->getMessage()], 500);
        }
        
    }
}
